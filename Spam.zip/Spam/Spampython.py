import streamlit as st
import pandas as pd
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

# Load the dataset
@st.cache
def load_data():
    df = pd.read_csv("spam.csv", encoding='latin-1')
    st.write(df.columns)
    return df

# Define a function to extract features from the messages
def extract_features(message):
    tokens = word_tokenize(message)
    tokens = [t for t in tokens if t.isalpha()]  # remove punctuation and numbers
    tokens = [t for t in tokens if t not in stopwords.words('english')]  # remove stopwords
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(t) for t in tokens]  # lemmatize tokens
    features = {}
    for token in tokens:
        features[token] = features.get(token, 0) + 1
    return features

# Create a Streamlit app
st.title("Spam Classification Web App")

# Load the dataset
df = load_data()

# Explore the dataset
st.write("Dataset Overview")
st.write(df.head())

# Split the dataset into training and testing sets
X = df['message'].apply(extract_features)
y = df['label']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Create a random forest classifier
rfc = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
rfc.fit(X_train, y_train)

# Evaluate the model
y_pred = rfc.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
st.write("Model Evaluation")
st.write(f"Accuracy: {accuracy:.3f}")

# Create a text input for the user to enter a message
input_message = st.text_input("Enter a message:")

# Create a button to make a prediction
if st.button("Predict"):
    # Extract features from the input message
    input_features = extract_features(input_message)
    
    # Convert the input features into a numerical representation
    input_features = pd.DataFrame([input_features])
    
    # Make a prediction
    prediction = rfc.predict(input_features)
    st.write(f"Prediction: {'Spam' if prediction[0] == 1 else 'Not Spam'}")